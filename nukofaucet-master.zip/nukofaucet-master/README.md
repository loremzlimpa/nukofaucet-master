# Nukofaucet
Nekonium Twitter faucet
# Features
* inspired by https://faucet.rinkeby.io/
* 1 nuko = 1 fresh tweet each day (must be tweeted less than 3 hours before submitting to this site)
* added extra secure layer using [botometer](https://botometer.iuni.iu.edu/#!/)
* opensource (I cound not find the source of https://faucet.rinkeby.io/)
# Install
* change bot's address, twitter api keys, mashape key [https://market.mashape.com/OSoMe/botometer](https://market.mashape.com/OSoMe/botometer)
* `npm install `
* `node index.js`
* open browser => [http://localhost:3000](http://localhost:3000)

# Donation for the faucet (not for myself)
http://nekonium.network/account/0x1ec366337ef2de16a5765700da06bb96a7312845

# License 
  Copyright 2018 @mike_theminer MIT License
